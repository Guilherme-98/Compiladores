#include <stdio.h>
#include <string.h>

#define ESTADOS 13

int get_indice(char c);
void imprimir_token(int ultimoEstadoFinal);

int main() {
	int transicoes[][128] = {
	/*		\n,  , +, -, ., 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p, q, r, s, t, u, v, w, x, y, z, OTHER*/
	/*0*/	{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
	/*1*/	{0, 12, 13, 9, 5, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 4, 4, 4, 4, 4, 4, 4, 4, 2, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 13},
	/*2*/	{0, 0, 0, 0, 0, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 3, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 0},
	/*3*/	{0, 0, 0, 0, 0, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 0},
	/*4*/	{0, 0, 0, 0, 0, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 0},
	/*5*/	{0, 0, 0, 0, 0, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
	/*6*/	{0, 0, 0, 0, 0, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
	/*7*/	{0, 0, 0, 0, 8, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
	/*8*/	{0, 0, 0, 0, 0, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
	/*9*/	{0, 0, 0, 10, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
	/*10*/	{11, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 0},
	/*11*/	{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
	/*12*/	{0, 12, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
	/*13*/	{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
	};

	int estadosFinais[ESTADOS+1] = {0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1};
	int estadoInicial = 1;
	int tamanhoEntrada;
	int i;

	char entrada[2048];

	int estadoAtual;
	int inicioCadeia;
	int cursorUltimoFinal;
	int ultimoEstadoFinal;
	int cursorAtual;

	while(fgets(entrada, sizeof(entrada), stdin)) {
		tamanhoEntrada = strlen(entrada);
		estadoAtual = 1;
		inicioCadeia = 0;
		ultimoEstadoFinal = 0;
		cursorUltimoFinal = 0;
		cursorAtual = -1;

		while(cursorAtual <= tamanhoEntrada) {
			cursorAtual++;
			estadoAtual = transicoes[estadoAtual][get_indice(entrada[cursorAtual])];

			if(estadoAtual == 0) {
				if(ultimoEstadoFinal == 0) {

					if(cursorAtual != inicioCadeia) {
						cursorAtual = inicioCadeia;
						inicioCadeia++;
					}
					else {
						inicioCadeia++;
					}
					estadoAtual = estadoInicial;
				}

				else {
					for(i = inicioCadeia; i <= cursorUltimoFinal; i++) {
						if(entrada[i] != 10 && entrada[i] != 32) {
							printf("%c", entrada[i]);
						}
					}

					imprimir_token(ultimoEstadoFinal);

					inicioCadeia = cursorUltimoFinal+1;
					cursorAtual = cursorUltimoFinal;
					estadoAtual = estadoInicial;
					ultimoEstadoFinal = 0;

					if(inicioCadeia != tamanhoEntrada) {
						printf("\n");
					}
				}
			}

			if(estadosFinais[estadoAtual]) {
				ultimoEstadoFinal = estadoAtual;
				cursorUltimoFinal = cursorAtual;
			}

			if(inicioCadeia == tamanhoEntrada) {;
				break;
			}
		}
	}
	return 0;
}

int get_indice(char c) {
	if(c == 10) return 0;
	else if(c == 32) return 1;
	else if(c == 43) return 2;
	else if(c == 45) return 3;
	else if(c == 46) return 4;
	else if(c >= 48 && c <= 57) return c-43;
	else if(c >= 97 && c <= 122) return c-82;
	else return 41;
}

void imprimir_token(int ultimoEstadoFinal) {
	if(ultimoEstadoFinal == 2) printf(" ID");
	else if(ultimoEstadoFinal == 3) printf(" IF");
	else if(ultimoEstadoFinal == 4) printf(" ID");
	else if(ultimoEstadoFinal == 5) printf(" error");
	else if(ultimoEstadoFinal == 6) printf(" REAL");
	else if(ultimoEstadoFinal == 7) printf(" NUM");
	else if(ultimoEstadoFinal == 8) printf(" REAL");
	else if(ultimoEstadoFinal == 9) printf(" error");
	else if(ultimoEstadoFinal == 12) printf("white space");
	else if(ultimoEstadoFinal == 11) printf(" comment\n");
	else if(ultimoEstadoFinal == 13) printf(" error");
}