#ifndef _SINTATICO_H_
#define _SINTATICO_H_

#define END_OF_FILE -1

#define IF 1
#define THEN 2
#define ELSE 3
#define BEGIN 4
#define END 5
#define PRINT 6
#define SEMI 7
#define NUM 8
#define EQ 9

#endif