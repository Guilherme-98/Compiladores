#include "lexico.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <string.h>
#include "automato.h"
#include "sintatico.h"

static char ultimo_token_lido[64];
static char ultimo_caractere_lido;
static char inicio_cadeia;

static int quebra_linha;

char* get_ultimo_token_lido() {
	return ultimo_token_lido;
}

char get_ultimo_caractere_lido() {
	return ultimo_caractere_lido;
}

void reset_quebra_linha() {
	quebra_linha = 0;
}

int leu_quebra_linha() {
	return quebra_linha;
}

int get_token() {
	char caractere_lido;
	int estado_atual = 1;
	int cursor_ultimo_final = 0;
	int ultimo_estado_final = 0;
	int cursor_atual = -1;
	int i;

	memset(ultimo_token_lido, 0, 64);

	formatar_inicio();

	while(1) {
		caractere_lido = fgetc(stdin);
		cursor_atual++;

		ultimo_caractere_lido = caractere_lido;

		if(caractere_lido == 10) {
			quebra_linha = 1;
		}

		if(cursor_atual == 0) {
			inicio_cadeia = caractere_lido;
		}

		ultimo_token_lido[cursor_atual] = caractere_lido;

		estado_atual = get_proximo_estado(estado_atual, caractere_lido);

		if(estado_atual == 0) {
			if(inicio_cadeia == -1) {
				return END_OF_FILE;
			}
			if(ultimo_estado_final == 0) {
				printf("ERRO LEXICO.");
				exit(0);
			}
			else {
				if(caractere_lido != -1) {
					fseek(stdin, (cursor_ultimo_final - cursor_atual),SEEK_CUR);
				}
				else {
					fseek(stdin, 1, SEEK_CUR);
				}
				ultimo_token_lido[cursor_atual] = '\0';
				return retornar_token(ultimo_estado_final);
			}
		}
		
		if(estado_final(estado_atual)) {
			ultimo_estado_final = estado_atual;
			cursor_ultimo_final = cursor_atual;
		}
	}
}