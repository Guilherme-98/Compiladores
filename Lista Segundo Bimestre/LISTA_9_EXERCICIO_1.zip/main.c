#include <stdio.h>
#include <stdlib.h>
#include "lexico.h"
#include "sintatico.h"

int token;
int token_anterior;
int erro_impresso;
int cadeia_imcompleta;

void S();
void L();
void E();

void erro(int t);
void comer(int t);
void avancar();
char* get_token_esperado(int t);
void avancar_cadeia();
char* get_token_errado();

int main() {
	int primeiro = 1;
	avancar();
	do {
		// Reseta valores
		erro_impresso = 0;
		cadeia_imcompleta = 0;
		reset_quebra_linha();
		// Caso nao seja a primeira iteracao printa \n no inicio
		if(primeiro) {
			primeiro = 0;
		} else {
			printf("\n");
		}
		// Funcao inicial do sintatico
		S();
		if(!erro_impresso) {
			printf("CADEIA ACEITA");
		}
		if(get_ultimo_caractere_lido() != -1 && erro_impresso && !cadeia_imcompleta) {
			avancar_cadeia();
		}
	} while(get_ultimo_caractere_lido() != -1);
	return 0;
}

void erro(int t) {
	if(erro_impresso) {
		return;
	}
	erro_impresso = 1;
	
	if(get_ultimo_caractere_lido() != 10 && leu_quebra_linha()) {
		cadeia_imcompleta = 1;
		printf("ERRO SINTATICO: CADEIA INCOMPLETA");
	}
	
	else {
		printf("ERRO SINTATICO EM: %s ESPERADO: %s", get_token_errado(), get_token_esperado(t));
	}
	return;
}

void avancar() {
	token = get_token();
}

void comer(int t) {
	if(erro_impresso) {
		return;
	}
	if(token == t) {
		avancar();
	}
	else {
		erro(t);
	}
}

void S(){
	if(erro_impresso) {
		return;
	}
	switch(token) {
		case IF: comer(IF); E(); comer(THEN); S(); comer(ELSE); S(); break;
		case BEGIN: comer(BEGIN); S(); L(); break;
		case PRINT: comer(PRINT); E(); break;
		default: erro_impresso = 1; printf("ERRO SINTATICO EM: %s ESPERADO: if, begin, print", get_token_errado()); return;
	}
}

void L(){
	if(erro_impresso) {
		return;
	}
	switch(token) {
		case END: comer(END); break;
		case SEMI: comer(SEMI); S(); L(); break;
		default: erro_impresso = 1; printf("ERRO SINTATICO EM: %s ESPERADO: end, ;", get_token_errado()); return;
	}
}

void E(){ 
	if(erro_impresso) {
		return;
	}
	comer(NUM); comer(EQ); comer(NUM); 
}

char* get_token_esperado(int t) {
	switch (t) {
		case IF: return "if";
		case THEN: return "then";
		case ELSE: return "else";
		case BEGIN: return "begin";
		case END: return "end";
		case PRINT: return "print";
		case SEMI: return ";";
		case NUM: return "num";
		case EQ: return "=";
	}
}

void avancar_cadeia() {
	char caractere_lido;
	caractere_lido = fgetc(stdin);
	while(caractere_lido != 10) {
		if(caractere_lido == -1) {
			exit(0);
		}
		caractere_lido = fgetc(stdin);
	}
	avancar();
}

char* get_token_errado() {
	if(token == NUM) {
		return "num";
	}
	return get_ultimo_token_lido();
}